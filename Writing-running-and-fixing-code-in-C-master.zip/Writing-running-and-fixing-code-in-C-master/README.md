# Writing-running-and-fixing-code-in-C
This is a repository reagarding the Coursera course on Writing, running and fixing code in C
